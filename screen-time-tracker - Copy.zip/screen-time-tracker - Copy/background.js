let remainingTime = 0;
let interval = null;
let paused = false;

function tick() {
  if (!paused && remainingTime > 0) {
    remainingTime--;
    broadcastTime();
  }
  if (remainingTime <= 0) clearInterval(interval);
}

function broadcastTime() {
  chrome.tabs.query({}, tabs => {
    for (let tab of tabs) {
      chrome.tabs.sendMessage(tab.id, {
        type: "update-time",
        time: remainingTime
      });
    }
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "start-timer") {
    remainingTime = msg.time;
    paused = false;
    clearInterval(interval);
    interval = setInterval(tick, 1000);
    broadcastTime();
  } else if (msg.type === "pause-timer") {
    paused = !paused;
  } else if (msg.type === "reset-timer") {
    remainingTime = 0;
    clearInterval(interval);
    broadcastTime();
  }
});
