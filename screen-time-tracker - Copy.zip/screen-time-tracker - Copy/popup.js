document.getElementById("startTimer").addEventListener("click", () => {
  const hours = parseInt(document.getElementById("hoursInput").value) || 0;
  const minutes = parseInt(document.getElementById("minutesInput").value) || 0;
  const totalSeconds = (hours * 60 + minutes) * 60;

  chrome.runtime.sendMessage({ type: "start-timer", time: totalSeconds });
});

document.getElementById("resetTimer").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "reset-timer" });
});
