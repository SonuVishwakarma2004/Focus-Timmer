function formatTime(seconds) {
  const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const s = String(seconds % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function createFloatingTimer() {
  if (document.getElementById('floating-timer')) return;

  const timer = document.createElement('div');
  timer.id = 'floating-timer';
  timer.innerHTML = `
    <div id="drag-handle" style="cursor: move; display: flex; justify-content: space-between; align-items: center;">
      <span>⏳ Timer</span>
      <button id="minimize-btn">–</button>
    </div>
    <div id="timer-body">
      <div id="timer-text">00:00:00</div>
      <div id="timer-controls">
        <button id="pause-btn">Pause</button>
        <button id="reset-btn">Reset</button>
      </div>
    </div>
  `;
  document.body.appendChild(timer);
  makeDraggable(timer);

  document.getElementById("pause-btn").onclick = () => chrome.runtime.sendMessage({ type: "pause-timer" });
  document.getElementById("reset-btn").onclick = () => chrome.runtime.sendMessage({ type: "reset-timer" });

  const minimizeBtn = document.getElementById("minimize-btn");
  const timerBody = document.getElementById("timer-body");
  let minimized = false;
  minimizeBtn.onclick = () => {
    minimized = !minimized;
    timerBody.style.display = minimized ? "none" : "block";
    minimizeBtn.textContent = minimized ? "+" : "–";
  };
}

function makeDraggable(el) {
  const handle = el.querySelector('#drag-handle');
  let isDragging = false, offsetX = 0, offsetY = 0;

  handle.addEventListener('mousedown', (e) => {
    isDragging = true;
    offsetX = e.clientX - el.offsetLeft;
    offsetY = e.clientY - el.offsetTop;
    document.body.style.userSelect = "none";
  });

  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    el.style.left = (e.clientX - offsetX) + 'px';
    el.style.top = (e.clientY - offsetY) + 'px';
  });

  document.addEventListener('mouseup', () => {
    isDragging = false;
    document.body.style.userSelect = "";
  });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "update-time") {
    createFloatingTimer();
    const text = document.getElementById("timer-text");
    if (text) text.textContent = formatTime(msg.time);
  }
});

createFloatingTimer(); // Injects floating timer on tab load



